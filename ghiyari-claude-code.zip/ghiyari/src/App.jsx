import { useState, useEffect, useRef } from "react";

// ════════════════════════════════════════════
// 🗄️  SUPABASE MOCK DATA LAYER
// ════════════════════════════════════════════
const PRODUCTS = [
  { id:"P001", name:{ar:"إطار تويوتا كامري 225/55R17",en:"Toyota Camry Tire 225/55R17"},
    category:"tires", brand:"toyota", price:450, comparePrice:520, rating:4.8, reviews:124,
    stock:45, dealer_id:"D001", icon:"🛞", tags:["bestseller","original"],
    specs:{Size:"225/55R17","Load Index":"97H",Type:"All-Season"},
    description:{ar:"إطار أصلي معتمد عالي الجودة مناسب لجميع الطرق والمناخات في الإمارات",
                 en:"Certified original high-quality tire suitable for all roads and UAE climates"},
    sku:"TYT-TIR-001", warranty:{ar:"سنتان",en:"2 years"} },

  { id:"P002", name:{ar:"بطارية لكزس ES350 أصلية",en:"Lexus ES350 Original Battery"},
    category:"batteries", brand:"lexus", price:680, comparePrice:750, rating:4.9, reviews:89,
    stock:12, dealer_id:"D002", icon:"🔋", tags:["original","premium"],
    specs:{Capacity:"65Ah",Voltage:"12V",CCA:"640A"},
    description:{ar:"بطارية أصلية عالية الأداء تضمن أفضل أداء للمحرك",
                 en:"Original high-performance battery ensuring optimal engine performance"},
    sku:"LEX-BAT-001", warranty:{ar:"3 سنوات",en:"3 years"} },

  { id:"P003", name:{ar:"براكات نيسان باترول أصلية",en:"Nissan Patrol Original Brakes"},
    category:"brakes", brand:"nissan", price:320, comparePrice:380, rating:4.7, reviews:156,
    stock:30, dealer_id:"D001", icon:"🔴", tags:["bestseller","original"],
    specs:{Thickness:"12mm",Diameter:"330mm",Type:"Ventilated Disc"},
    description:{ar:"براكات أصلية معتمدة مع أعلى معايير السلامة والأداء",
                 en:"Certified original brakes with highest safety and performance standards"},
    sku:"NIS-BRK-001", warranty:{ar:"سنة واحدة",en:"1 year"} },

  { id:"P004", name:{ar:"إطار بي إم دبليو 5 سيريز 245/45R18",en:"BMW 5 Series Tire 245/45R18"},
    category:"tires", brand:"bmw", price:750, comparePrice:850, rating:4.9, reviews:67,
    stock:20, dealer_id:"D003", icon:"🛞", tags:["premium","original"],
    specs:{Size:"245/45R18","Load Index":"100Y",Type:"Performance"},
    description:{ar:"إطار بريميوم مصمم خصيصاً لسيارات بي إم دبليو الفاخرة",
                 en:"Premium tire specifically engineered for BMW luxury vehicles"},
    sku:"BMW-TIR-001", warranty:{ar:"سنتان",en:"2 years"} },

  { id:"P005", name:{ar:"بطارية تويوتا لاندكروزر",en:"Toyota Land Cruiser Battery"},
    category:"batteries", brand:"toyota", price:520, comparePrice:600, rating:4.6, reviews:201,
    stock:25, dealer_id:"D001", icon:"🔋", tags:["bestseller"],
    specs:{Capacity:"80Ah",Voltage:"12V",CCA:"750A"},
    description:{ar:"بطارية قوية مناسبة للبيئات الصعبة والطرق الوعرة في الإمارات",
                 en:"Powerful battery suitable for harsh UAE environments and rough terrain"},
    sku:"TYT-BAT-002", warranty:{ar:"سنتان",en:"2 years"} },

  { id:"P006", name:{ar:"براكات مرسيدس C300 فرونت",en:"Mercedes C300 Front Brakes"},
    category:"brakes", brand:"mercedes", price:580, comparePrice:650, rating:4.8, reviews:45,
    stock:8, dealer_id:"D003", icon:"🔴", tags:["premium","original"],
    specs:{Thickness:"14mm",Diameter:"350mm",Type:"Ceramic"},
    description:{ar:"براكات سيراميك أصلية للأداء الأمثل والهدوء التام",
                 en:"Original ceramic brakes for optimal performance and complete silence"},
    sku:"MRC-BRK-001", warranty:{ar:"سنتان",en:"2 years"} },
];

const DEALERS = [
  { id:"D001", name:{ar:"مجموعة الإمارات لقطع الغيار",en:"Emirates Auto Parts Group"},
    location:{ar:"دبي - منطقة الراشدية",en:"Dubai - Al Rashidiya"}, rating:4.9,
    totalSales:1250, verified:true, tier:"platinum",
    certs:["ISO 9001","Toyota Certified","Nissan Authorized"], phone:"+971501234567" },
  { id:"D002", name:{ar:"الفخامة لقطع السيارات",en:"Luxury Auto Parts"},
    location:{ar:"أبو ظبي - المصفح",en:"Abu Dhabi - Mussafah"}, rating:4.8,
    totalSales:890, verified:true, tier:"gold",
    certs:["Lexus Certified","BMW Authorized"], phone:"+971507654321" },
  { id:"D003", name:{ar:"بريميوم أوتو بارتس",en:"Premium Auto Parts UAE"},
    location:{ar:"الشارقة - المنطقة الصناعية",en:"Sharjah - Industrial Area"}, rating:4.7,
    totalSales:650, verified:true, tier:"gold",
    certs:["BMW Certified","Mercedes Authorized"], phone:"+971509876543" },
];

const STATS = {
  totalRevenue:284500, totalOrders:1247, activeProducts:856,
  activeDealers:47, monthlyGrowth:23.5, avgOrderValue:425,
  conversionRate:4.2, satisfaction:96,
};

// ════════════════════════════════════════════
// 🤖  CLAUDE AI SERVICE
// ════════════════════════════════════════════
const callGhiyariAI = async (history, lang) => {
  const system = `You are Ghiyari AI — an expert assistant for UAE auto spare parts marketplace.
${lang==="ar" ? "CRITICAL: Always respond in Arabic (عربي فصيح بسيط)." : "CRITICAL: Always respond in English."}

You are knowledgeable about:
- Tires, brakes, batteries for Toyota, Nissan, Lexus, BMW, Mercedes
- UAE market pricing in AED, typical maintenance schedules
- Part compatibility, specifications, quality differences (OEM vs aftermarket)
- Dubai/Abu Dhabi/Sharjah service locations

Current Inventory:
• Toyota Camry Tire 225/55R17 → 450 AED (Bestseller)
• Lexus ES350 Battery 65Ah → 680 AED (Premium)
• Nissan Patrol Brakes Ventilated → 320 AED (Bestseller)
• BMW 5 Series Tire 245/45R18 → 750 AED (Premium)
• Toyota Land Cruiser Battery 80Ah → 520 AED
• Mercedes C300 Front Brakes Ceramic → 580 AED

Be concise (3-5 lines max), helpful, and professional. End with a relevant product recommendation when appropriate.`;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify({
      model:"claude-sonnet-4-20250514",
      max_tokens:1000,
      system,
      messages: history.map(m=>({role:m.role, content:m.content}))
    })
  });
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return data.content[0]?.text || (lang==="ar" ? "عذراً، حدث خطأ." : "Sorry, an error occurred.");
};

// ════════════════════════════════════════════
// 🌍  TRANSLATIONS
// ════════════════════════════════════════════
const T = {
  ar:{
    appName:"غياري", tagline:"قطع أصلية • موثوقة • معتمدة",
    home:"الرئيسية", products:"المنتجات", ai:"مساعد AI", admin:"الإدارة",
    cart:"السلة", addToCart:"أضف للسلة", buyNow:"اشتر الآن",
    checkout:"الدفع الآمن", remove:"حذف", search:"بحث",
    all:"الكل", tires:"الإطارات", brakes:"البراكات", batteries:"البطاريات",
    allBrands:"كل العلامات", inStock:"متوفر", outOfStock:"غير متوفر",
    original:"أصلي", bestseller:"الأكثر مبيعاً", premium:"بريميوم",
    verified:"موزع معتمد", warranty:"الضمان", specs:"المواصفات",
    totalPrice:"الإجمالي", emptyCart:"السلة فارغة",
    totalRevenue:"إجمالي الإيرادات", totalOrders:"الطلبات",
    activeProducts:"المنتجات النشطة", activeDealers:"الموزعون",
    aiWelcome:"مرحباً! 🤖 أنا مساعد غياري الذكي\n\nأستطيع مساعدتك في:\n• اختيار الإطار المناسب\n• تشخيص مشاكل الفرامل\n• متى تبدّل البطارية\n• مقارنة الأسعار والجودة",
    aiPlaceholder:"اسألني عن قطع غيار سيارتك...",
    newsletter:"اشترك في النشرة البريدية",
    newsletterDesc:"احصل على أحدث العروض عبر Mailchimp",
    subscribe:"اشترك", emailPlaceholder:"بريدك الإلكتروني",
    subscribeOk:"✅ تم الاشتراك! ستصلك العروض قريباً",
    back:"رجوع", leftInStock:"متبقي",
    shopifyNote:"🔒 دفع آمن عبر Shopify",
    supabase:"Supabase DB", shopify:"Shopify Cart",
    mailchimp:"Mailchimp", claude:"Claude AI",
    connected:"متصل", integrations:"حالة التكاملات",
    viewAll:"عرض الكل", shopNow:"تسوق الآن", askAI:"اسأل AI",
    featuredProducts:"🔥 الأكثر مبيعاً",
    thisMonth:"هذا الشهر", left:"متبقي",
    overview:"نظرة عامة", dealers:"الموزعون", productsList:"المنتجات",
    convRate:"معدل التحويل", avgOrder:"متوسط الطلب", satisfaction:"رضا العملاء",
    sales:"مبيعة", available:"منتج متوفر",
  },
  en:{
    appName:"Ghiyari", tagline:"Genuine • Reliable • Certified",
    home:"Home", products:"Products", ai:"AI Assistant", admin:"Admin",
    cart:"Cart", addToCart:"Add to Cart", buyNow:"Buy Now",
    checkout:"Secure Checkout", remove:"Remove", search:"Search",
    all:"All", tires:"Tires", brakes:"Brakes", batteries:"Batteries",
    allBrands:"All Brands", inStock:"In Stock", outOfStock:"Out of Stock",
    original:"Original", bestseller:"Bestseller", premium:"Premium",
    verified:"Certified Dealer", warranty:"Warranty", specs:"Specs",
    totalPrice:"Total", emptyCart:"Cart is empty",
    totalRevenue:"Total Revenue", totalOrders:"Orders",
    activeProducts:"Active Products", activeDealers:"Dealers",
    aiWelcome:"Hello! 🤖 I'm Ghiyari AI Assistant\n\nI can help you with:\n• Choosing the right tire\n• Diagnosing brake issues\n• When to replace battery\n• Price & quality comparison",
    aiPlaceholder:"Ask about your car parts...",
    newsletter:"Newsletter Subscription",
    newsletterDesc:"Get the latest offers via Mailchimp",
    subscribe:"Subscribe", emailPlaceholder:"Your email address",
    subscribeOk:"✅ Subscribed! Offers coming soon",
    back:"Back", leftInStock:"left",
    shopifyNote:"🔒 Secure checkout via Shopify",
    supabase:"Supabase DB", shopify:"Shopify Cart",
    mailchimp:"Mailchimp", claude:"Claude AI",
    connected:"Connected", integrations:"Integration Status",
    viewAll:"View All", shopNow:"Shop Now", askAI:"Ask AI",
    featuredProducts:"🔥 Bestsellers",
    thisMonth:"this month", left:"left",
    overview:"Overview", dealers:"Dealers", productsList:"Products",
    convRate:"Conversion Rate", avgOrder:"Avg Order Value", satisfaction:"Satisfaction",
    sales:"sales", available:"products available",
  }
};

// ════════════════════════════════════════════
// 🎨  ICON COMPONENTS
// ════════════════════════════════════════════
const Ic = {
  Home:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>,
  Box:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>,
  Bot:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/><line x1="8" y1="16" x2="8" y2="16"/><line x1="16" y1="16" x2="16" y2="16"/></svg>,
  Settings:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><circle cx="12" cy="12" r="3"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>,
  Cart:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>,
  Star:()=><svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
  Send:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>,
  X:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  Plus:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  Minus:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-4 h-4"><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  Search:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
  Shield:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
  Truck:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>,
  Check:()=><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-4 h-4"><polyline points="20 6 9 17 4 12"/></svg>,
};

// ════════════════════════════════════════════
// 🃏  PRODUCT CARD
// ════════════════════════════════════════════
function ProductCard({ p, lang, t, onAdd, onView, added }) {
  const disc = Math.round(((p.comparePrice - p.price) / p.comparePrice) * 100);
  return (
    <div onClick={()=>onView(p)}
      className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border border-gray-100 cursor-pointer transition-all duration-300 hover:-translate-y-1 group relative">
      {added && (
        <div className="absolute inset-0 bg-emerald-500/90 z-10 rounded-2xl flex items-center justify-center">
          <span className="text-white text-lg font-black">✓ {lang==="ar"?"أُضيف!":"Added!"}</span>
        </div>
      )}
      {/* Image area */}
      <div className="bg-gradient-to-br from-slate-50 to-blue-50 group-hover:from-blue-50 group-hover:to-indigo-100 transition-all duration-300 p-8 h-40 flex items-center justify-center relative">
        <span className="text-6xl">{p.icon}</span>
        <div className="absolute top-2 start-2 flex flex-col gap-1">
          {disc>0 && <span className="bg-red-500 text-white text-xs font-black px-2 py-0.5 rounded-full">-{disc}%</span>}
          {p.tags.includes("bestseller") && <span className="bg-amber-400 text-white text-xs font-bold px-2 py-0.5 rounded-full">{t.bestseller}</span>}
          {p.tags.includes("original") && <span className="bg-emerald-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">{t.original}</span>}
        </div>
        {p.stock<15 && <div className="absolute bottom-2 end-2 bg-orange-100 text-orange-700 text-xs px-2 py-0.5 rounded-full font-semibold">{p.stock} {t.leftInStock}</div>}
      </div>
      {/* Info */}
      <div className="p-4">
        <h3 className="font-bold text-gray-900 text-sm leading-snug line-clamp-2 mb-2">{p.name[lang]}</h3>
        <div className="flex items-center gap-1 mb-3">
          <span className="text-amber-400"><Ic.Star /></span>
          <span className="text-sm font-bold text-gray-900">{p.rating}</span>
          <span className="text-xs text-gray-400">({p.reviews})</span>
          <span className={`ms-auto text-xs font-semibold ${p.stock>0?"text-emerald-600":"text-red-500"}`}>{p.stock>0?t.inStock:t.outOfStock}</span>
        </div>
        <div className="flex items-end justify-between mb-3">
          <div>
            <span className="text-xl font-black text-blue-600">{p.price}</span>
            <span className="text-xs text-gray-500 ms-1">د.إ</span>
            {p.comparePrice>p.price && <span className="text-xs text-gray-400 line-through ms-2">{p.comparePrice}</span>}
          </div>
        </div>
        <button onClick={e=>{e.stopPropagation();onAdd(p);}}
          className="w-full bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold py-2.5 rounded-xl text-sm transition-all">
          {t.addToCart}
        </button>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════
// 🔍  PRODUCT DETAIL MODAL
// ════════════════════════════════════════════
function ProductModal({ p, lang, t, onAdd, onClose }) {
  const dealer = DEALERS.find(d=>d.id===p.dealer_id);
  const disc = Math.round(((p.comparePrice - p.price) / p.comparePrice) * 100);
  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-end sm:items-center justify-center p-3" onClick={onClose}>
      <div className="bg-white rounded-3xl w-full max-w-md max-h-[92vh] overflow-y-auto" onClick={e=>e.stopPropagation()}>
        <div className="flex justify-end p-4 pb-0">
          <button onClick={onClose} className="p-2 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"><Ic.X /></button>
        </div>
        <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-12 flex items-center justify-center">
          <span className="text-8xl">{p.icon}</span>
        </div>
        <div className="p-6 space-y-4">
          <div className="flex flex-wrap gap-2">
            {disc>0 && <span className="bg-red-100 text-red-700 text-xs font-black px-3 py-1 rounded-full">-{disc}%</span>}
            {p.tags.includes("original") && <span className="bg-emerald-100 text-emerald-700 text-xs font-bold px-3 py-1 rounded-full">{t.original}</span>}
            {p.tags.includes("bestseller") && <span className="bg-amber-100 text-amber-700 text-xs font-bold px-3 py-1 rounded-full">{t.bestseller}</span>}
          </div>
          <h2 className="text-2xl font-black text-gray-900">{p.name[lang]}</h2>
          <div className="flex items-center gap-2">
            <span className="text-amber-400 flex"><Ic.Star /></span>
            <span className="font-bold">{p.rating}</span>
            <span className="text-gray-500 text-sm">({p.reviews} {lang==="ar"?"تقييم":"reviews"})</span>
          </div>
          <p className="text-gray-600 text-sm leading-relaxed">{p.description[lang]}</p>
          {/* Specs */}
          <div className="bg-gray-50 rounded-2xl p-4">
            <p className="font-bold text-gray-900 mb-3 text-sm">{t.specs}</p>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(p.specs).map(([k,v])=>(
                <div key={k} className="bg-white rounded-xl p-3">
                  <p className="text-xs text-gray-400">{k}</p>
                  <p className="text-sm font-bold text-gray-900">{v}</p>
                </div>
              ))}
            </div>
          </div>
          {/* Trust */}
          <div className="grid grid-cols-3 gap-2">
            {[
              {icon:<Ic.Truck />, label:lang==="ar"?"توصيل مجاني":"Free Delivery", bg:"bg-blue-50"},
              {icon:<Ic.Shield />, label:p.warranty[lang], bg:"bg-emerald-50"},
              {icon:"✅", label:t.verified, bg:"bg-amber-50"},
            ].map((b,i)=>(
              <div key={i} className={`${b.bg} rounded-2xl p-3 flex flex-col items-center gap-1 text-center`}>
                <div className="text-gray-600">{typeof b.icon==="string"?<span>{b.icon}</span>:b.icon}</div>
                <p className="text-xs text-gray-700 font-medium leading-tight">{b.label}</p>
              </div>
            ))}
          </div>
          {/* Dealer */}
          {dealer && (
            <div className="border border-gray-100 rounded-2xl p-4">
              <p className="font-bold text-gray-900 text-sm mb-1">🏪 {dealer.name[lang]}</p>
              <p className="text-xs text-gray-500 mb-2">📍 {dealer.location[lang]}</p>
              <div className="flex flex-wrap gap-1">
                {dealer.certs.map((c,i)=><span key={i} className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">{c}</span>)}
              </div>
            </div>
          )}
          {/* Price + CTA */}
          <div className="flex items-center gap-4 pt-2">
            <div>
              <span className="text-4xl font-black text-blue-600">{p.price}</span>
              <span className="text-gray-500 ms-1">د.إ</span>
              {p.comparePrice>p.price && <p className="text-xs text-gray-400 line-through">{p.comparePrice} د.إ</p>}
            </div>
            <button onClick={()=>{onAdd(p);onClose();}}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-2xl text-base transition-colors active:scale-95">
              {t.addToCart}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════
// 🤖  AI CHAT
// ════════════════════════════════════════════
function AIChat({ lang, t }) {
  const [msgs, setMsgs] = useState([{ role:"assistant", content:t.aiWelcome }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(()=>{ endRef.current?.scrollIntoView({behavior:"smooth"}); },[msgs]);

  const quickQs = lang==="ar"
    ? ["ما الإطار المناسب لتويوتا كامري؟","متى أغير البطارية؟","براكات أصلية أم بديلة؟","عروض اليوم"]
    : ["Best tire for Toyota Camry?","When to replace battery?","OEM vs aftermarket brakes?","Today's deals"];

  const send = async () => {
    if(!input.trim()||loading) return;
    const q = input.trim();
    setInput("");
    const newMsgs = [...msgs, {role:"user",content:q}];
    setMsgs(newMsgs);
    setLoading(true);
    try {
      const reply = await callGhiyariAI(
        newMsgs.map(m=>({role:m.role,content:m.content})), lang
      );
      setMsgs(prev=>[...prev,{role:"assistant",content:reply}]);
    } catch(e) {
      setMsgs(prev=>[...prev,{role:"assistant",content:lang==="ar"?"⚠️ خطأ في الاتصال. تحقق من الإنترنت وحاول مجدداً.":"⚠️ Connection error. Please try again."}]);
    } finally { setLoading(false); }
  };

  return (
    <div className="flex flex-col h-full">
      {/* AI Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-4 rounded-t-2xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center text-xl">🤖</div>
          <div className="flex-1">
            <p className="font-black text-white">{lang==="ar"?"مساعد غياري الذكي":"Ghiyari AI Assistant"}</p>
            <p className="text-xs text-blue-200">{lang==="ar"?"مدعوم بـ Claude AI الحقيقي":"Powered by Real Claude AI"}</p>
          </div>
          <div className="flex items-center gap-1.5 bg-emerald-500 text-white text-xs px-2.5 py-1 rounded-full">
            <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
            {lang==="ar"?"متصل":"Live"}
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 bg-gray-50 space-y-3 min-h-0">
        {msgs.map((m,i)=>(
          <div key={i} className={`flex ${m.role==="user"?"justify-end":"justify-start"} items-end gap-2`}>
            {m.role==="assistant" && <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm flex-shrink-0">🤖</div>}
            <div className={`max-w-[80%] px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
              m.role==="user"
                ? "bg-blue-600 text-white rounded-2xl rounded-ee-sm"
                : "bg-white text-gray-800 shadow-sm border border-gray-100 rounded-2xl rounded-es-sm"
            }`}>{m.content}</div>
          </div>
        ))}
        {loading && (
          <div className="flex items-end gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm">🤖</div>
            <div className="bg-white rounded-2xl px-4 py-3 shadow-sm border border-gray-100">
              <div className="flex gap-1">
                {[0,150,300].map(d=><span key={d} className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{animationDelay:`${d}ms`}}></span>)}
              </div>
            </div>
          </div>
        )}
        <div ref={endRef}/>
      </div>

      {/* Quick questions */}
      {msgs.length<=2 && (
        <div className="bg-gray-50 border-t border-gray-100 p-3 flex gap-2 overflow-x-auto">
          {quickQs.map((q,i)=>(
            <button key={i} onClick={()=>setInput(q)}
              className="text-xs bg-white border border-blue-200 text-blue-700 px-3 py-2 rounded-full whitespace-nowrap hover:bg-blue-50 flex-shrink-0 transition-colors">
              {q}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="p-4 bg-white border-t border-gray-100 rounded-b-2xl">
        <div className="flex gap-2">
          <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()}
            placeholder={t.aiPlaceholder} disabled={loading}
            className="flex-1 border border-gray-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100"/>
          <button onClick={send} disabled={loading||!input.trim()}
            className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white p-2.5 rounded-xl transition-colors active:scale-95">
            <Ic.Send />
          </button>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════
// 📊  ADMIN DASHBOARD
// ════════════════════════════════════════════
function AdminDash({ lang, t }) {
  const [tab, setTab] = useState("overview");
  const cards = [
    {label:t.totalRevenue, val:`${STATS.totalRevenue.toLocaleString()} د.إ`, change:`+${STATS.monthlyGrowth}%`, icon:"💰"},
    {label:t.totalOrders, val:STATS.totalOrders.toLocaleString(), change:"+18%", icon:"📦"},
    {label:t.activeProducts, val:STATS.activeProducts, change:"+32", icon:"🛞"},
    {label:t.activeDealers, val:STATS.activeDealers, change:"+5", icon:"🏪"},
  ];
  const integrations = [
    {label:t.supabase, icon:"🗄️"}, {label:t.shopify, icon:"🛒"},
    {label:t.mailchimp, icon:"📧"}, {label:t.claude, icon:"🤖"},
  ];
  return (
    <div className="space-y-5">
      {/* Integrations */}
      <div className="bg-white rounded-2xl p-4 border border-gray-100">
        <p className="font-bold text-gray-900 text-sm mb-3">🔗 {t.integrations}</p>
        <div className="grid grid-cols-2 gap-2">
          {integrations.map((item,i)=>(
            <div key={i} className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-xl p-2.5">
              <span>{item.icon}</span>
              <span className="text-xs font-semibold text-gray-700 flex-1">{item.label}</span>
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            </div>
          ))}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3">
        {cards.map((c,i)=>(
          <div key={i} className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm">
            <div className="text-2xl mb-2">{c.icon}</div>
            <p className="text-xl font-black text-gray-900">{c.val}</p>
            <p className="text-xs text-gray-500 mt-0.5">{c.label}</p>
            <p className="text-xs text-emerald-600 font-bold mt-1">{c.change} {t.thisMonth}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="flex border-b border-gray-100">
          {["overview","dealers","productsList"].map(tb=>(
            <button key={tb} onClick={()=>setTab(tb)}
              className={`flex-1 py-3 text-xs font-bold transition-colors ${tab===tb?"text-blue-600 border-b-2 border-blue-600 bg-blue-50":"text-gray-500 hover:bg-gray-50"}`}>
              {t[tb]}
            </button>
          ))}
        </div>
        <div className="p-4">
          {tab==="overview" && (
            <div className="space-y-4">
              {[
                {label:t.convRate, val:`${STATS.conversionRate}%`, pct:STATS.conversionRate*10, color:"bg-blue-500"},
                {label:t.avgOrder, val:`${STATS.avgOrderValue} د.إ`, pct:70, color:"bg-indigo-500"},
                {label:t.satisfaction, val:`${STATS.satisfaction}%`, pct:STATS.satisfaction, color:"bg-emerald-500"},
              ].map((item,i)=>(
                <div key={i}>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="text-gray-600">{item.label}</span>
                    <span className="font-black text-gray-900">{item.val}</span>
                  </div>
                  <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                    <div className={`h-full ${item.color} rounded-full transition-all duration-1000`} style={{width:`${item.pct}%`}}/>
                  </div>
                </div>
              ))}
            </div>
          )}
          {tab==="dealers" && (
            <div className="space-y-3">
              {DEALERS.map(d=>(
                <div key={d.id} className="flex items-start gap-3 bg-gray-50 rounded-xl p-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-base flex-shrink-0 ${d.tier==="platinum"?"bg-purple-100":"bg-amber-100"}`}>🏪</div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-gray-900 text-sm truncate">{d.name[lang]}</p>
                    <p className="text-xs text-gray-500">{d.location[lang]}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-amber-500 text-xs flex items-center gap-0.5"><Ic.Star />{d.rating}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${d.tier==="platinum"?"bg-purple-100 text-purple-700":"bg-amber-100 text-amber-700"}`}>{d.tier}</span>
                    </div>
                  </div>
                  <span className="text-xs text-emerald-600 font-bold">{d.totalSales} {t.sales}</span>
                </div>
              ))}
            </div>
          )}
          {tab==="productsList" && (
            <div className="space-y-2">
              {PRODUCTS.map(p=>(
                <div key={p.id} className="flex items-center gap-3 bg-gray-50 rounded-xl p-3">
                  <span className="text-2xl">{p.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-gray-900 text-sm truncate">{p.name[lang]}</p>
                    <p className="text-xs text-gray-500">{p.price} د.إ • {lang==="ar"?`مخزون: ${p.stock}`:`Stock: ${p.stock}`}</p>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-amber-500 font-bold">
                    <Ic.Star />{p.rating}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════
// 📧  NEWSLETTER (Mailchimp)
// ════════════════════════════════════════════
function Newsletter({ lang, t }) {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const sub = async () => {
    if(!email.includes("@")) return;
    setLoading(true);
    await new Promise(r=>setTimeout(r,900)); // Mailchimp API hook
    setDone(true); setLoading(false);
  };
  return (
    <div className="bg-gradient-to-br from-indigo-600 to-blue-700 text-white rounded-3xl p-6">
      <p className="text-3xl mb-3">📧</p>
      <h3 className="text-lg font-black mb-1">{t.newsletter}</h3>
      <p className="text-blue-200 text-sm mb-4">{t.newsletterDesc}</p>
      {done ? (
        <div className="bg-white/20 rounded-2xl p-4 text-center font-bold">{t.subscribeOk}</div>
      ) : (
        <div className="flex gap-2">
          <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder={t.emailPlaceholder}
            className="flex-1 bg-white/20 border border-white/30 text-white placeholder-blue-200 rounded-xl px-4 py-2.5 text-sm outline-none focus:bg-white/30"/>
          <button onClick={sub} disabled={loading}
            className="bg-white text-blue-700 font-black px-4 py-2.5 rounded-xl text-sm hover:bg-blue-50 transition-colors disabled:opacity-70">
            {loading?"...":t.subscribe}
          </button>
        </div>
      )}
      <p className="text-xs text-blue-300 mt-3">🔒 {lang==="ar"?"محمي بـ Mailchimp":"Protected by Mailchimp"}</p>
    </div>
  );
}

// ════════════════════════════════════════════
// 🛒  CART SIDEBAR
// ════════════════════════════════════════════
function CartSidebar({ cart, lang, t, onRemove, onQty, onClose }) {
  const total = cart.reduce((s,i)=>s+(i.price*i.qty),0);
  const doCheckout = () => alert(lang==="ar"
    ? `🛒 جاري الانتقال لـ Shopify Checkout...\n\nالإجمالي: ${total} د.إ\n\n(في الإنتاج: صفحة دفع آمنة بـ Apple Pay / بطاقة)`
    : `🛒 Redirecting to Shopify Checkout...\n\nTotal: ${total} AED\n\n(In production: Secure payment with Apple Pay / Card)`);
  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex" onClick={onClose}>
      <div className={`bg-white h-full w-full max-w-sm shadow-2xl flex flex-col ${lang==="ar"?"ms-auto":"me-auto"}`}
        onClick={e=>e.stopPropagation()}>
        <div className="bg-blue-600 text-white p-5 flex items-center justify-between">
          <h2 className="text-lg font-black flex items-center gap-2"><Ic.Cart />{t.cart}</h2>
          <button onClick={onClose} className="p-1.5 bg-white/20 hover:bg-white/30 rounded-full transition-colors"><Ic.X /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length===0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-400">
              <div className="text-5xl mb-4">🛒</div><p>{t.emptyCart}</p>
            </div>
          ) : cart.map(item=>(
            <div key={item.id} className="bg-gray-50 rounded-2xl p-4 flex gap-3">
              <span className="text-3xl">{item.icon}</span>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-sm text-gray-900 truncate">{item.name[lang]}</p>
                <p className="text-blue-600 font-black mt-1">{item.price*item.qty} د.إ</p>
                <div className="flex items-center gap-2 mt-2">
                  <button onClick={()=>onQty(item.id,item.qty-1)} className="w-7 h-7 bg-gray-200 hover:bg-gray-300 rounded-full flex items-center justify-center transition-colors"><Ic.Minus /></button>
                  <span className="font-black w-6 text-center text-sm">{item.qty}</span>
                  <button onClick={()=>onQty(item.id,item.qty+1)} className="w-7 h-7 bg-gray-200 hover:bg-gray-300 rounded-full flex items-center justify-center transition-colors"><Ic.Plus /></button>
                  <button onClick={()=>onRemove(item.id)} className="ms-auto text-red-400 hover:text-red-600 transition-colors"><Ic.X /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
        {cart.length>0 && (
          <div className="p-4 border-t border-gray-100 space-y-3">
            <div className="flex justify-between items-center">
              <span className="font-semibold text-gray-600">{t.totalPrice}</span>
              <span className="text-2xl font-black text-blue-600">{total} <span className="text-base">د.إ</span></span>
            </div>
            <button onClick={doCheckout}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-2xl text-base transition-colors active:scale-95">
              {t.checkout} →
            </button>
            <p className="text-xs text-gray-400 text-center">{t.shopifyNote}</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ════════════════════════════════════════════
// 🏠  MAIN APP
// ════════════════════════════════════════════
export default function GhiyariApp() {
  const [lang, setLang] = useState("ar");
  const [page, setPage] = useState("home");
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [modal, setModal] = useState(null);
  const [search, setSearch] = useState("");
  const [cat, setCat] = useState("all");
  const [brand, setBrand] = useState("all");
  const [addedId, setAddedId] = useState(null);
  const t = T[lang];

  const filtered = PRODUCTS.filter(p=>{
    const mc = cat==="all"||p.category===cat;
    const mb = brand==="all"||p.brand===brand;
    const ms = !search||p.name[lang].toLowerCase().includes(search.toLowerCase())||p.category.includes(search.toLowerCase());
    return mc&&mb&&ms;
  });

  const addToCart = p => {
    setCart(prev=>{
      const ex=prev.find(i=>i.id===p.id);
      if(ex) return prev.map(i=>i.id===p.id?{...i,qty:i.qty+1}:i);
      return [...prev,{...p,qty:1}];
    });
    setAddedId(p.id);
    setTimeout(()=>setAddedId(null),1500);
  };
  const removeFromCart = id => setCart(prev=>prev.filter(i=>i.id!==id));
  const updateQty = (id,qty) => qty<=0 ? removeFromCart(id) : setCart(prev=>prev.map(i=>i.id===id?{...i,qty}:i));
  const cartCount = cart.reduce((s,i)=>s+i.qty,0);

  const navItems = [
    {id:"home", icon:<Ic.Home />, label:t.home},
    {id:"products", icon:<Ic.Box />, label:t.products},
    {id:"ai", icon:<Ic.Bot />, label:t.ai},
    {id:"admin", icon:<Ic.Settings />, label:t.admin},
  ];

  return (
    <div dir={lang==="ar"?"rtl":"ltr"} className="min-h-screen bg-gray-50 font-sans select-none">
      {/* ── HEADER ── */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
        <div className="max-w-2xl mx-auto px-4 h-16 flex items-center justify-between">
          <button onClick={()=>setPage("home")} className="flex items-center gap-2">
            <span className="text-2xl font-black text-blue-600">{t.appName}</span>
            <span className="hidden sm:block text-xs text-gray-400 font-medium">{t.tagline}</span>
          </button>
          <div className="flex items-center gap-2">
            <button onClick={()=>setLang(lang==="ar"?"en":"ar")}
              className="text-xs font-bold text-gray-600 px-3 py-1.5 border border-gray-200 rounded-full hover:bg-gray-50 transition-colors">
              {lang==="ar"?"EN":"عر"}
            </button>
            <button onClick={()=>setCartOpen(true)}
              className="relative p-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-colors active:scale-95">
              <Ic.Cart />
              {cartCount>0 && (
                <span className="absolute -top-1.5 -end-1.5 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-black">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* ── MAIN ── */}
      <main className="max-w-2xl mx-auto px-4 py-6 pb-28">

        {/* HOME */}
        {page==="home" && (
          <div className="space-y-6">
            {/* Hero */}
            <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-900 text-white rounded-3xl p-7 relative overflow-hidden">
              <div className="absolute -top-4 -end-4 text-[120px] opacity-10 select-none">🚗</div>
              <span className="text-xs font-bold text-blue-300 bg-blue-900/50 px-3 py-1 rounded-full">🇦🇪 {lang==="ar"?"منصة الإمارات":"UAE Platform"}</span>
              <h1 className="text-3xl font-black mt-4 mb-3 leading-tight">
                {lang==="ar"?"قطع غيار أصلية\nبضغطة واحدة":"Original Spare Parts\nat Your Fingertips"}
              </h1>
              <p className="text-blue-300 text-sm mb-6">{lang==="ar"?"أسرع منصة لقطع غيار السيارات في الإمارات — موزعون معتمدون":"Fastest UAE auto parts platform — Certified dealers"}</p>
              <div className="flex gap-3">
                <button onClick={()=>setPage("products")} className="bg-blue-500 hover:bg-blue-400 text-white font-black px-5 py-2.5 rounded-xl text-sm transition-colors active:scale-95">
                  {t.shopNow} →
                </button>
                <button onClick={()=>setPage("ai")} className="bg-white/15 hover:bg-white/25 text-white font-bold px-5 py-2.5 rounded-xl text-sm transition-colors flex items-center gap-2">
                  🤖 {t.askAI}
                </button>
              </div>
            </div>

            {/* Category cards */}
            <div className="grid grid-cols-3 gap-3">
              {[
                {id:"tires",icon:"🛞",label:t.tires,from:"from-blue-50",to:"to-blue-100",border:"border-blue-200"},
                {id:"brakes",icon:"🔴",label:t.brakes,from:"from-red-50",to:"to-red-100",border:"border-red-200"},
                {id:"batteries",icon:"🔋",label:t.batteries,from:"from-emerald-50",to:"to-emerald-100",border:"border-emerald-200"},
              ].map(c=>(
                <button key={c.id} onClick={()=>{setCat(c.id);setPage("products");}}
                  className={`bg-gradient-to-br ${c.from} ${c.to} border ${c.border} rounded-2xl p-4 text-center hover:shadow-md active:scale-95 transition-all`}>
                  <div className="text-3xl mb-2">{c.icon}</div>
                  <p className="text-sm font-bold text-gray-800">{c.label}</p>
                </button>
              ))}
            </div>

            {/* Bestsellers */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-black text-gray-900">{t.featuredProducts}</h2>
                <button onClick={()=>setPage("products")} className="text-blue-600 text-sm font-bold">{t.viewAll} →</button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {PRODUCTS.filter(p=>p.tags.includes("bestseller")).map(p=>(
                  <ProductCard key={p.id} p={p} lang={lang} t={t} onAdd={addToCart} onView={setModal} added={addedId===p.id}/>
                ))}
              </div>
            </div>

            {/* Newsletter */}
            <Newsletter lang={lang} t={t} />

            {/* Integration status */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100">
              <p className="text-sm font-black text-gray-900 mb-3">🔗 {t.integrations}</p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  {label:"Supabase DB",note:lang==="ar"?"منتجات وموزعون":"Products & Dealers"},
                  {label:"Shopify",note:lang==="ar"?"سلة ودفع":"Cart & Checkout"},
                  {label:"Mailchimp",note:lang==="ar"?"حملات بريدية":"Email Campaigns"},
                  {label:"Claude AI",note:lang==="ar"?"بحث ذكي":"Smart Search"},
                ].map((item,i)=>(
                  <div key={i} className="flex items-center gap-2 p-2.5 bg-emerald-50 rounded-xl">
                    <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse flex-shrink-0"></span>
                    <div className="min-w-0">
                      <p className="text-xs font-black text-gray-800">{item.label}</p>
                      <p className="text-xs text-gray-500 truncate">{item.note}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* PRODUCTS */}
        {page==="products" && (
          <div className="space-y-4">
            <h1 className="text-2xl font-black text-gray-900">{t.products}</h1>
            {/* Search */}
            <div className="relative">
              <span className="absolute inset-y-0 start-4 flex items-center text-gray-400 pointer-events-none"><Ic.Search /></span>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder={`${t.search}...`}
                className="w-full bg-white border border-gray-200 rounded-2xl ps-12 pe-4 py-3.5 text-sm outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100"/>
            </div>
            {/* Category filter */}
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
              {[{id:"all",label:t.all},{id:"tires",label:t.tires},{id:"brakes",label:t.brakes},{id:"batteries",label:t.batteries}].map(c=>(
                <button key={c.id} onClick={()=>setCat(c.id)}
                  className={`px-4 py-2 rounded-full font-bold text-sm whitespace-nowrap transition-all ${cat===c.id?"bg-blue-600 text-white shadow-md":"bg-white text-gray-600 border border-gray-200 hover:bg-gray-50"}`}>
                  {c.label}
                </button>
              ))}
            </div>
            {/* Brand filter */}
            <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
              {["all","toyota","nissan","lexus","bmw","mercedes"].map(b=>(
                <button key={b} onClick={()=>setBrand(b)}
                  className={`px-3 py-1.5 rounded-full font-bold text-xs whitespace-nowrap border transition-all ${brand===b?"bg-gray-900 text-white border-gray-900":"bg-white text-gray-600 border-gray-200 hover:bg-gray-50"}`}>
                  {b==="all"?t.allBrands:b[0].toUpperCase()+b.slice(1)}
                </button>
              ))}
            </div>
            <p className="text-sm text-gray-500">{filtered.length} {t.available}</p>
            {filtered.length>0 ? (
              <div className="grid grid-cols-2 gap-4">
                {filtered.map(p=>(
                  <ProductCard key={p.id} p={p} lang={lang} t={t} onAdd={addToCart} onView={setModal} added={addedId===p.id}/>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 text-gray-400">
                <div className="text-5xl mb-4">🔍</div>
                <p className="font-semibold">{lang==="ar"?"لا توجد منتجات مطابقة":"No products found"}</p>
              </div>
            )}
          </div>
        )}

        {/* AI */}
        {page==="ai" && (
          <div className="space-y-4">
            <h1 className="text-2xl font-black text-gray-900">🤖 {t.ai}</h1>
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden" style={{height:"calc(100vh - 240px)"}}>
              <AIChat lang={lang} t={t}/>
            </div>
          </div>
        )}

        {/* ADMIN */}
        {page==="admin" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-black text-gray-900">{t.admin}</h1>
              <span className="text-xs bg-blue-100 text-blue-700 font-bold px-3 py-1 rounded-full">v2.0</span>
            </div>
            <AdminDash lang={lang} t={t}/>
          </div>
        )}
      </main>

      {/* ── BOTTOM NAV ── */}
      <nav className="fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-gray-100 shadow-lg safe-area-pb">
        <div className="max-w-2xl mx-auto flex">
          {navItems.map(item=>(
            <button key={item.id} onClick={()=>setPage(item.id)}
              className={`flex-1 flex flex-col items-center gap-1 py-3 transition-colors ${page===item.id?"text-blue-600":"text-gray-400"}`}>
              <div className={`p-1.5 rounded-xl transition-all ${page===item.id?"bg-blue-100":""}`}>{item.icon}</div>
              <span className="text-[10px] font-bold">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* ── CART ── */}
      {cartOpen && <CartSidebar cart={cart} lang={lang} t={t} onRemove={removeFromCart} onQty={updateQty} onClose={()=>setCartOpen(false)}/>}

      {/* ── PRODUCT MODAL ── */}
      {modal && <ProductModal p={modal} lang={lang} t={t} onAdd={addToCart} onClose={()=>setModal(null)}/>}
    </div>
  );
}
