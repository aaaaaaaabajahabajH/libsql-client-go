# 🚗 غياري — Ghiyari Auto Parts Platform

> منصة رقمية متكاملة لقطع غيار السيارات في الإمارات العربية المتحدة

---

## ⚡ تشغيل سريع

```bash
# طريقة 1: الإعداد التلقائي
bash setup.sh

# طريقة 2: يدوياً
npm install
cp .env.example .env   # ثم أضف مفاتيح API
npm run dev            # → http://localhost:5173
```

---

## 🔗 التكاملات

```
🤖 Claude AI  → src/App.jsx :: callGhiyariAI()
🗄️ Supabase   → src/App.jsx :: PRODUCTS / DEALERS (mock جاهز)
🛒 Shopify    → src/App.jsx :: CartSidebar :: doCheckout()
📧 Mailchimp  → src/App.jsx :: Newsletter :: sub()
```

---

## 📁 الملفات الرئيسية

| الملف | الغرض |
|-------|--------|
| `CLAUDE.md` | **اقرأه أولاً** — تعليمات Claude Code الكاملة |
| `src/App.jsx` | التطبيق الكامل (مكوّن واحد — مرشّح للتجزئة) |
| `.env.example` | قالب متغيرات البيئة |
| `setup.sh` | سكريبت الإعداد التلقائي |

---

## 🛠️ أوامر Claude Code المفيدة

```bash
# طلب تجزئة الكود إلى components
claude "جزّئ src/App.jsx إلى components منفصلة"

# طلب ربط Supabase الحقيقي
claude "اربط src/App.jsx مع Supabase باستخدام المتغيرات في .env"

# طلب إضافة React Router
claude "أضف React Router للتنقل بين الصفحات"

# طلب إضافة Zustand للحالة
claude "أضف Zustand لإدارة سلة التسوق بدلاً من useState"
```

---

## 📊 التقنيات

- **React 18** + **Vite 5**
- **Tailwind CSS 3** (RTL/LTR)
- **Anthropic Claude AI** (بحث ذكي)
- **Supabase** (قاعدة بيانات — جاهز للربط)
- **Shopify** (متجر ودفع — جاهز للربط)
- **Mailchimp** (تسويق — جاهز للربط)

---

## 🗺️ Roadmap

- [ ] تجزئة `App.jsx` إلى components
- [ ] ربط Supabase الحقيقي
- [ ] ربط Shopify Storefront API
- [ ] إضافة React Router
- [ ] إضافة Zustand
- [ ] صفحة تفاصيل الطلب
- [ ] لوحة تحكم الموزع
- [ ] تطبيق موبايل (React Native)

---

*© 2024 Ghiyari — All rights reserved*
